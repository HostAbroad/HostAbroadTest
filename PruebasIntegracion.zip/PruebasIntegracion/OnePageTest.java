package PruebasIntegracion;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.junit.Assert;
import org.junit.Before;
import org.junit.jupiter.api.Test;

import com.vaadin.demo.jpaaddressbook.OnePage;
import com.vaadin.demo.jpaaddressbook.domain.Name;

class OnePageTest {
	OnePage ventana = new OnePage();
	String nombre = "Maria";
	
	/* IMPORTANTE 
	 * Si ejecutas testCreateName, cambiar la lista de testReadAllNames, ya que hay una nueva entidad
	 * que no se tiene en cuenta y daria error
	 */
	
	@Test
	void testCreateName() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("addressbook");
        EntityManager em = emf.createEntityManager();
        Name m = null;
        
        em.getTransaction().begin();
        
        //Crea la entrada Maria en la base de datos
        this.ventana.createName(this.nombre);
        
        //guarda todos las entradas de la base de datos
        List<Name> ar = em.createNativeQuery("SELECT * FROM Name", Name.class).getResultList();
        
        em.close( );
        emf.close( );
        
        //busca la entrada que se llame maria
        for(Name n : ar) {
        	if(n.getName().equals(this.nombre))
        		m = n;
        }
        
        Assert.assertEquals(m.getName(), this.nombre);
	}
	
	@Test
	void testReadAllNames() {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("addressbook");
        EntityManager em = emf.createEntityManager();
        
        //lista con las entididades que hay hasta el momento
		List<Name> original = new ArrayList<Name>();
		original.add(new Name("adrian"));
		original.add(new Name("pedro"));
		original.add(new Name("bg"));
		original.add(new Name("Maria"));
		original.add(new Name("Maria"));
		original.add(new Name("Maria"));
		original.add(new Name("Maria"));
		
		em.getTransaction().begin();
		
		//lista con las entidades que devuelve OnePage
		List<Name> bd = this.ventana.readAllNames();
		
		em.close( );
	    emf.close( );
		
	    //compara una a una las entidades de ambas listas
	    for(int i = 0; i < bd.size(); i++) {
	    	Assert.assertEquals(bd.get(i).getName(), original.get(i).getName());
	    }
	    
	}

}
