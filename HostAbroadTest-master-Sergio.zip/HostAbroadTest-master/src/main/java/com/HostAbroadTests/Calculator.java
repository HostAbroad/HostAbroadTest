package com.HostAbroadTests;

public class Calculator {
	
	public Calculator(int operator1, int operator2) {
		super();
		this.operator1 = operator1;
		this.operator2 = operator2;
	}
	
	private int operator1;
	private int operator2;
	
	public int add() {
		return operator1 + operator2;
	}
	
	public int subtract() {
		return operator1 - operator2;
	}
	
	public int multiply() {
		return operator1 * operator2;
	}
	
	public int divide() {
		return operator1 / operator2;
	}

}
