package com.HostAbroadTests;

import static org.junit.Assert.assertEquals;

import static org.junit.Assert.assertTrue;
 
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class AppTest 
{
	private static Calculator calculator;
	
	@BeforeClass
    public static void initCalculator() {
        calculator = new Calculator(4, 2);
    }
	
	@Before
	public void initMessage() {
		System.out.println("Running tests");
	}
	
	@Test
	public void testAdd() {
		assertEquals(6, calculator.add());
	}
	
	@Test
	public void testSubstract() {
		assertEquals(2, calculator.subtract());
	}
	
	@Test
	public void testMultiply() {
		assertEquals(8, calculator.multiply());
	}
	
	@Test
	public void testDivide() {
		assertEquals(2, calculator.divide());
	}
	
	@After
	public void finishMessage() {
		System.out.println("Finish tests phase");
	}
	
    
    @Test
    public void shouldAnswerWithTrue()
    {
        assertTrue( true );
    }
}
